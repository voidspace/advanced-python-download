import csv
from openpyxl import Workbook

def read_portfolio(filename):
    portfolio = []
    with open(filename) as f:
        rows = csv.reader(f)
        next(rows)
        for row in rows:
            name = row[0]
            amount = int(row[1])
            price = float(row[2])
            portfolio.append((name, amount, price))
    return portfolio


if __name__ == '__main__':
    portfolio = read_portfolio('Data/portfolio.csv')
    headers = 'Name', 'Shares', 'Price'

    wb = Workbook()

    sheet = wb.active
    sheet.title = 'Portfolio'

    for col, header in zip('ABC', headers):
        sheet[f'{col}1'].value = header

    for row, data in enumerate(portfolio, start=2):
        for col, value in enumerate(data, start=1):
            sheet.cell(row=row, column=col).value = value

    wb.save('portfolio.xlsx')

