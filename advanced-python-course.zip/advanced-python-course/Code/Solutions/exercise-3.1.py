import csv


def read_portfolio(filename):
    portfolio = []
    with open(filename) as f:
        rows = csv.reader(f)
        headers = next(rows)
        for row in rows:
            name = row[0]
            try:
                amount = int(row[1])
                price = float(row[2])
            except (ValueError, IndexError) as e:
                print(f"Couldn't parse: {row!r}")
                print(f"Reason: {type(e)}:{e}")
                continue
            portfolio.append((name, amount, price))
    return portfolio


import random
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def possibly_exploding_code():
    exc = random.choice([IndexError, ValueError, TypeError, None])
    if exc is not None:
        raise exc

try:
    possibly_exploding_code()
except IndexError:
    logger.error("Not enough data")
except ValueError:
    logger.error("Data out of bounds")
except TypeError:
    logger.error("Wrong data")
else:
    logger.info("Success")
finally:
    logger.info("Complete")