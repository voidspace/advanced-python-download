from openpyxl import load_workbook

wb = load_workbook('Data/unesco-world-heritage-2019.xlsx')

sheet = wb['site properties']

##########
# Part 1
##########

spanish_sites = []

rows = sheet.rows

# Pop of the titles
next(rows)

# Column B
country_index = 1
# Column D
number_index = 3
# Column G
name_index = 6

for row in rows:
    if row[country_index].value == 'Spain':
        spanish_sites.append((row[number_index].value, row[name_index].value))

print(f'Total number of UNESCO sites in Spain: {len(spanish_sites)}')
for site in spanish_sites:
    print(f'Site number: {site[0]}    Site name: {site[1]}')

print()
print()

##########
# Part 2
##########

biggest = (0, 0)

rows = sheet.rows

# Pop of the titles
next(rows)

for i, row in enumerate(rows, 2):
    try:
        area = float(row[16].value)
    except TypeError:
        continue

    if area > biggest[1]:
        biggest = (i, area)

biggest_row_number, biggest_area = biggest
country = sheet[f'B{biggest_row_number}'].value
number = sheet[f'D{biggest_row_number}'].value
name = sheet[f'G{biggest_row_number}'].value

print(f'The biggest site is "{name}" in {country} with site number {number} and an area of {biggest_area:.2f} hectares')








