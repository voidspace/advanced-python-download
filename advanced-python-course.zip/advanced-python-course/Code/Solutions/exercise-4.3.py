import csv


class Stock:

    def __init__(self, name, shares, price):
        self.name = name
        self.shares = shares
        self.price = price

    def cost(self):
        return self.shares * self.price

    def sell(self, nshares):
        self.shares -= nshares

    @classmethod
    def from_row(cls, row):
        name = row[0]
        shares = int(row[1])
        price = float(row[2])
        return cls(name, shares, price)


if __name__ == '__main__':
    filename = 'Data/portfolio.csv'
    portfolio = []
    with open(filename) as f:
        rows = csv.reader(f)
        headers = next(rows)
        for row in rows:
            portfolio.append(Stock.from_row(row))
