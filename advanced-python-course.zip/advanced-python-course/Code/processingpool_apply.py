import multiprocessing

def add(x, y):
    return x + y

if __name__ == '__main__':
    p = multiprocessing.Pool()
    r = p.apply(add, (3, 4))
    print(r)