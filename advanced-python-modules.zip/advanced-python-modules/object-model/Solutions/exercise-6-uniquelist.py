class UniqueList:
    """A sequence that behaves like a set by discarding duplicates while maintaining order"""
    def __init__(self):
        self.items = []

    def __getitem__(self, index):
        return self.items[index]

    def __setitem__(self, index, value):
        # If the value is already in the list at a different position,
        # we don't change anything
        if value in self.items and self.items[index] != value:
            return
        self.items[index] = value

    def __delitem__(self, index):
        del self.items[index]

    def __contains__(self, value):
        return value in self.items

    def __len__(self):
        return len(self.items)

    def __iter__(self):
        return iter(self.items)

    def __repr__(self):
        return f"UniqueList({self.items})"

    def append(self, value):
        # Only append if the value isn't already in the list
        if value not in self.items:
            self.items.append(value)

    def insert(self, index, value):
        # Only insert if the value isn't already in the list
        if value not in self.items:
            self.items.insert(index, value)

    def extend(self, items):
        for item in items:
            self.append(item)


### Implementation two: using collections.abc.Sequence

from collections.abc import Sequence
from typing import Any, List, Iterator


class UniqueList(Sequence):
    """A sequence that behaves like a set by discarding duplicates while maintaining order"""

    def __init__(self, iterable=None):
        self._items = []
        if iterable is not None:
            self.extend(iterable)

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, index):
        return self._items[index]

    def __iter__(self) -> Iterator:
        return iter(self._items)

    def append(self, item: Any) -> None:
        if item not in self._items:
            self._items.append(item)

    def extend(self, items: List[Any]) -> None:
        for item in items:
            self.append(item)

    def insert(self, index: int, item: Any) -> None:
        if item not in self._items:
            self._items.insert(index, item)

    def __add__(self, other):
        result = UniqueList(self)
        result.extend(other)
        return result

    def __iadd__(self, other):
        self.extend(other)
        return self

    def __eq__(self, other) -> bool:
        if isinstance(other, (UniqueList, list)):
            return self._items == other
        return NotImplemented

    def __repr__(self) -> str:
        return f"UniqueList({self._items})"
