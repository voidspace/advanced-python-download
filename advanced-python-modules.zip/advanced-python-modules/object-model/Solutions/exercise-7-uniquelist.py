class UniqueList:
    def __init__(self):
        self.items = []

    def __getitem__(self, index):
        return self.items[index]

    def __setitem__(self, index, value):
        # If the value is already in the list at a different position,
        # we don't change anything
        if value in self.items and self.items[index] != value:
            return
        self.items[index] = value

    def __delitem__(self, index):
        del self.items[index]

    def __contains__(self, value):
        return value in self.items

    def __len__(self):
        return len(self.items)

    def __iter__(self):
        return iter(self.items)

    def __repr__(self):
        return f"UniqueList({self.items})"

    def append(self, value):
        # Only append if the value isn't already in the list
        if value not in self.items:
            self.items.append(value)

    def insert(self, index, value):
        # Only insert if the value isn't already in the list
        if value not in self.items:
            self.items.insert(index, value)
