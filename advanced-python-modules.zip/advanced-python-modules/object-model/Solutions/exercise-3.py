import csv


class Item:

    def __init__(self, name, amount, price):
        self.name = name
        self.amount = amount
        self.price = price

    @property
    def amount(self):
        return self._amount

    @amount.setter
    def amount(self, value):
        if not isinstance(value, int) or value < 0:
            raise TypeError(f'Expected positive int got {value!r}')
        self._amount = value

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, value):
        if not isinstance(value, float) or value < 0:
            raise TypeError(f'Expected positive float got {value!r}')
        self._price = value

    def cost(self):
        return self.amount * self.price

    def sell(self, namount):
        self.amount -= namount

    @classmethod
    def from_row(cls, row):
        name = row[0]
        amount = int(row[1])
        price = float(row[2])
        return cls(name, amount, price)


if __name__ == '__main__':
    filename = 'inventory.csv'
    inventory = []
    with open(filename) as f:
        rows = csv.reader(f)
        headers = next(rows)
        for row in rows:
            inventory.append(Item.from_row(row))
