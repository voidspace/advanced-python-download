# Exercise 1
numbers = [x for x in range(1, 21) if x % 2 == 0]

# Exercise 2
sentence = "The quick brown fox jumps over the lazy dog"
word_lengths = [len(word) for word in sentence.split() if len(word) > 3]

# Exercise 3
number_pairs = [(x, x**2) for x in range(1, 11) if x % 2 == 0 and x % 3 == 0]

# Exercise 4
store_items = {
    "apple": 0.5,
    "banana": 1.0,
    "orange": 0.75,
    "mango": 2.5,
    "laptop": 999.99,
    "book": 7.99,
    "pen": 1.99
}
affordable_items = [item for item, price in store_items.items() if price < 10]

# Exercise 5
words = ["Hello", "World", "Python", "Programming", "Language"]
a_words_upper = [word.upper() for word in words if 'a' in word.lower()]
