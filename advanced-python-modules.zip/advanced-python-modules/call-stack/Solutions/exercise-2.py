import csv
from dataclasses import dataclass


@dataclass
class Item:
    name: str
    amount: int
    price: float


def read_inventory(filename, ignore_missing_file=False):
    inventory = []
    try:
        with open(filename) as f:
            rows = csv.reader(f)
            headers = next(rows)
            for row in rows:
                name = row[0]
                try:
                    amount = int(row[1])
                    price = float(row[2])
                except (ValueError, IndexError) as e:
                    print(f"Couldn't parse: {row!r}")
                    print(f"Reason: {type(e)}:{e}")
                    continue
                else:
                    inventory.append(Item(name, amount, price))
    except FileNotFoundError:
        if not ignore_missing_file:
            raise
    return inventory
