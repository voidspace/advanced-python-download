import random
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def possibly_exploding_code():
    exc = random.choice([IndexError, ValueError, TypeError, None])
    if exc is not None:
        raise exc("Boom!")


try:
    possibly_exploding_code()
except IndexError:
    logger.error("Not enough data")
except ValueError:
    logger.error("Data out of bounds")
except TypeError:
    logger.error("Wrong data")
else:
    logger.info("Success")
finally:
    logger.info("Complete")
