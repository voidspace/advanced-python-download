import time
from collections.abc import Callable
from typing import Any

class OperationError(Exception):
    pass


def perform_operation():
    # Simulate an unreliable operation
    import random
    if random.random() < 0.7:  # 70% chance of failure
        raise OperationError("Operation failed")
    return "Operation successful"



DEFAULT_MAX_RETRIES = 5


class TaskEngine:
    def __init__(self, tasks: list[Callable], retries: int = DEFAULT_MAX_RETRIES):
        self.tasks = tasks
        self.retries = retries
        self.results = []

    def do_tasks(self):
        self.results = [self.do_task(task) for task in self.tasks]

    def do_task(self, task: Callable) -> Any:
        for attempt in range(self.retries):
            try:
                result = task()
            except OperationError as e:
                wait_time = 2 ** attempt  # Exponential backoff
                if attempt < self.retries - 1:
                    print(f"Attempt {attempt + 1} failed. Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                else:
                    print("All retry attempts failed")
                    raise
            else:
                return result


if __name__ == '__main__':
    t = TaskEngine([perform_operation], retries=4)
    t.do_tasks()
    print(t.results)
