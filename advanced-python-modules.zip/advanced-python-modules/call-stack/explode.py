# explode.py
# Call stack and debugging demo

def bam():
    data = {"here": "is", "some": "data"}
    raise RuntimeError("oh dear")


def baz():
    foo = 999
    try:
        bam()
    except ValueError:
        print("Ouch bam")
    print("done baz")


def bar():
    x = 33
    v = 99
    baz()
    print("done bar")


def foo():
    y = 57
    a = "hello"
    try:
        bar()
    except TypeError:
        print("Ouch bar")
    print("done foo")


if __name__ == "__main__":
    foo()
