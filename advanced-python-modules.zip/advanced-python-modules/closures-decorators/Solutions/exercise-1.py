def delayed_add(x, y):
    def do_add():
        return x + y
    return do_add

def make_adder(x):
    def adder(y):
        return x + y
    return adder

#########


import csv


def typedproperty(name, typ):
    private_name = '_' + name

    def getter(self):
        return getattr(self, private_name)

    def setter(self, value):
        if not isinstance(value, typ):
            raise TypeError(f'Expected {typ} got {value!r}')
        setattr(self, private_name, value)

    return property(getter, setter)


class Item:
    name = typedproperty('name', str)
    amount = typedproperty('amount', int)
    price = typedproperty('price', float)

    def __init__(self, name, amount, price):
        self.name = name
        self.amount = amount
        self.price = price

    def cost(self):
        return self.amount * self.price

    @classmethod
    def from_row(cls, row):
        name = row[0]
        amount = int(row[1])
        price = float(row[2])
        return cls(name, amount, price)

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.__dict__ == other.__dict__

    def __repr__(self):
        return f'{self.__class__.__name__}(name={self.name!r}, amount={self.amount!r}, price={self.price!r}'


if __name__ == '__main__':
    filename = 'Data/portfolio.csv'
    portfolio = []
    with open(filename) as f:
        rows = csv.reader(f)
        headers = next(rows)
        for row in rows:
            portfolio.append(Item.from_row(row))


##########################

def counter(value):
    def incr():
        nonlocal value
        value += 1
        return value

    def decr():
        nonlocal value
        value -= 1
        return value

    return incr, decr
