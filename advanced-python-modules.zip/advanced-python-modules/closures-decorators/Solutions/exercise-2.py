# memoize.py

def memoize(func):
    cache = {}
    def inner(*args):
        if args in cache:
            return cache[args]
        result = func(*args)
        cache[args] = result
        return result
    return inner