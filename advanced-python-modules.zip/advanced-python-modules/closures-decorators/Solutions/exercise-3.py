from functools import wraps


def logformat(message):
    def logged(func):
        @wraps(func)
        def inner(*args, **kwargs):
            print(message.format(func=func))
            return func(*args, **kwargs)

        return inner

    return logged


logged = logformat('Calling {func.__name__}')


class Spam:
    @logged
    def instance_method(self):
        print('Instance method')

    @classmethod
    @logged
    def class_method(cls):
        print('Class method')

    @staticmethod
    @logged
    def static_method():
        print('Static method')

    @property
    @logged
    def property(self):
        print('Property')
