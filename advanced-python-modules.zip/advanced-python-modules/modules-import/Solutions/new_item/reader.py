import csv
from new_item.item import Item

# CSV reading

def read_inventory(filename):
    '''
    Read a CSV file into a list of instances
    '''
    records = []
    with open(filename) as f:
        rows = csv.reader(f)
        headers = next(rows)
        for row in rows:
            records.append(Item.from_row(row))
    return records
