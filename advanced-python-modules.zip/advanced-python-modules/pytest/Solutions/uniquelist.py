from collections.abc import Sequence
from typing import Any, List, Iterator


class UniqueList(Sequence):
    """A sequence that behaves like a set by discarding duplicates while maintaining order"""

    def __init__(self, iterable=None):
        self._items = []
        if iterable is not None:
            self.extend(iterable)

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, index):
        return self._items[index]

    def __iter__(self) -> Iterator:
        return iter(self._items)

    def append(self, item: Any) -> None:
        if item not in self._items:
            self._items.append(item)

    def extend(self, items: List[Any]) -> None:
        for item in items:
            self.append(item)

    def insert(self, index: int, item: Any) -> None:
        if item not in self._items:
            self._items.insert(index, item)

    def __add__(self, other):
        result = UniqueList(self)
        result.extend(other)
        return result

    def __iadd__(self, other):
        self.extend(other)
        return self

    def __eq__(self, other) -> bool:
        if isinstance(other, (UniqueList, list)):
            return self._items == other
        return NotImplemented

    def __repr__(self) -> str:
        return f"UniqueList({self._items})"
