import pytest

@pytest.fixture
def empty_list():
    return UniqueList()


@pytest.fixture
def populated_list():
    return UniqueList([1, 2, 3])


@pytest.fixture
def duplicate_data():
    return [1, 2, 2, 3, 3, 3]
