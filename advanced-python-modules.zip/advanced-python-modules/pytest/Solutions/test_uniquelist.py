import pytest

from uniquelist import UniqueList

# Section 1: Simple Tests
# These tests cover basic functionality without parametrization or fixtures

def test_empty_list():
    ul = UniqueList()
    assert len(ul) == 0
    assert list(ul) == []


def test_simple_append():
    ul = UniqueList()
    ul.append(1)
    assert list(ul) == [1]


def test_duplicate_append():
    ul = UniqueList()
    ul.append(1)
    ul.append(1)
    assert list(ul) == [1]


def test_basic_iteration():
    ul = UniqueList([1, 2, 3])
    items = []
    for item in ul:
        items.append(item)
    assert items == [1, 2, 3]


def test_basic_membership():
    ul = UniqueList([1, 2, 3])
    assert 1 in ul
    assert 4 not in ul


def test_basic_equality():
    ul = UniqueList([1, 2, 3])
    assert ul == [1, 2, 3]
    assert ul != [1, 2]


def test_basic_repr():
    ul = UniqueList([1, 2, 3])
    assert repr(ul) == "UniqueList([1, 2, 3])"


# Section 2: Parameterized Tests
# These tests use pytest's parametrize feature to test multiple scenarios

@pytest.mark.parametrize("input_list,expected", [
    ([], []),
    ([1, 2, 3], [1, 2, 3]),
    ([1, 1, 2, 2, 3], [1, 2, 3]),
    ([1, 2, 1, 3, 2], [1, 2, 3]),
    (['a', 'b', 'a'], ['a', 'b']),
])
def test_initialization(input_list, expected):
    ul = UniqueList(input_list)
    assert list(ul) == expected
    assert len(ul) == len(expected)


@pytest.mark.parametrize("index,expected", [
    (0, 1),
    (1, 2),
    (-1, 3),
    (slice(None, None), [1, 2, 3]),
    (slice(1, None), [2, 3]),
    (slice(None, -1), [1, 2]),
    (slice(1, -1), [2]),
])
def test_indexing_and_slicing(index, expected):
    ul = UniqueList([1, 2, 3])
    assert ul[index] == expected


@pytest.mark.parametrize("other,expected", [
    ([4, 5], [1, 2, 3, 4, 5]),
    ([1, 2], [1, 2, 3]),
    ([3, 4, 3, 5], [1, 2, 3, 4, 5]),
])
def test_addition_operations(other, expected):
    ul = UniqueList([1, 2, 3])
    # Test regular addition
    result = ul + other
    assert list(result) == expected
    assert isinstance(result, UniqueList)
    # Test in-place addition
    ul += other
    assert list(ul) == expected


# Section 3: Fixture-based Tests
# These tests use pytest fixtures for setup and reuse
# The fixtures live in conftest.py

def test_append_to_empty(empty_list):
    empty_list.append(1)
    assert list(empty_list) == [1]


def test_extend_with_duplicates(empty_list, duplicate_data):
    empty_list.extend(duplicate_data)
    assert list(empty_list) == [1, 2, 3]


def test_operations_on_populated(populated_list):
    # Test multiple operations on the same fixture
    populated_list.append(4)
    assert list(populated_list) == [1, 2, 3, 4]
    populated_list.extend([4, 5, 6])
    assert list(populated_list) == [1, 2, 3, 4, 5, 6]
    populated_list.insert(0, 0)
    assert list(populated_list) == [0, 1, 2, 3, 4, 5, 6]


def test_multiple_fixtures(empty_list, populated_list, duplicate_data):
    # Test interaction between fixtures
    empty_list.extend(duplicate_data)
    result = empty_list + populated_list
    assert list(result) == [1, 2, 3]
