class Config:
    CORS_ORIGIN = "*"

    SF_USERNAME = "someone@somewhere.com"
    SF_PASSWORD = "SomePassword23!"
