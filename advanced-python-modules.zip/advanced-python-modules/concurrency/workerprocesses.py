import multiprocessing

def worker(i):
    print(f'Worker {i}')

if __name__ == '__main__':
    for i in range(3):
        p = multiprocessing.Process(target=worker, args=(i,))
        p.start()
