import multiprocessing
import time


def add(x, y):
    return x + y


if __name__ == '__main__':
    p = multiprocessing.Pool()
    r = p.apply_async(add, (3, 4))  # r is an ApplyResult object

    # We could call r.wait([timeout])
    while not r.ready():
        time.sleep(0.1)

    print(r.ready())
    print(r.successful())
    print(r.get())  # get has an optional timeout param
