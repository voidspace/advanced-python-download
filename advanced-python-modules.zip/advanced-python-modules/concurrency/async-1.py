import asyncio

loop = asyncio.new_event_loop()

async def first():
    print("one")
    print(await other())
    print("three")

async def other():
    return "two"

loop.run_until_complete(first())
