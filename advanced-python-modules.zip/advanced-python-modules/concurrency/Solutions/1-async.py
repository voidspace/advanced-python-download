"""
Simple Async URL Fetcher Exercise

This exercise demonstrates basic async concepts by fetching multiple URLs concurrently.
It compares synchronous vs asynchronous approaches to show the benefits of async programming.
"""

import asyncio
import aiohttp
import time
from typing import Any


async def fetch_url(session: aiohttp.ClientSession, url: str) -> dict[str, Any]:
    """
    Fetch a single URL and return its status and content length.

    Args:
        session: Shared aiohttp session for making requests
        url: URL to fetch

    Returns:
        Dictionary containing the URL, status code, and content length
    """
    try:
        async with session.get(url) as response:
            content = await response.text()
    except Exception as e:
        return {
            'url': url,
            'status': None,
            'content_length': 0,
            'success': False,
            'error': str(e)
        }
    else:
        return {
            'url': url,
            'status': response.status,
            'content_length': len(content),
            'success': True
        }


async def fetch_urls_async(urls: list[str]) -> list[dict]:
    """
    Fetch multiple URLs concurrently using asyncio.

    Args:
        urls: List of URLs to fetch

    Returns:
        List of dictionaries containing results for each URL
    """
    async with aiohttp.ClientSession() as session:
        # Create tasks for all URLs
        tasks = [fetch_url(session, url) for url in urls]
        # Wait for all tasks to complete
        results = await asyncio.gather(*tasks)
        return results


async def main():
    # List of URLs to fetch
    urls = [
        'http://example.com',
        'http://httpbin.org/get',
        'http://python.org',
        'http://httpstat.us/200',
        'http://httpstat.us/404',  # Will return 404 status
        'http://this-does-not-exist.com'  # Will fail
    ]

    print("Starting URL fetcher...\n")

    # Time the async operation
    start_time = time.time()
    results = await fetch_urls_async(urls)
    duration = time.time() - start_time

    # Print results
    print(f"\nResults (completed in {duration:.2f} seconds):")
    print("-" * 60)

    for result in results:
        # Create status message
        if result['success']:
            status = f"✓ Status: {result['status']}, Length: {result['content_length']}"
        else:
            status = f"✗ Error: {result['error']}"

        print(f"{result['url']:<30} {status}")


if __name__ == "__main__":
    asyncio.run(main())
