import asyncio

async def thing():
    return "one"

async def asyncgen():
    yield await thing() # await allowed!
    yield "two"

async def function():
    async for value in asyncgen():
       print(value)

asyncio.run(function())
