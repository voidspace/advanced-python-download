
class FRange:
    def __init__(self, start, stop, step):
        self.start = start
        self.stop = stop
        self.step = step
    def __iter__(self):
        n = self.start
        while n < self.stop:
            yield n
            n += self.step


class Item:
    ...
    def __iter__(self):
        for name in ("name", "shares", "price"):
            yield getattr(self, name)
    ...
