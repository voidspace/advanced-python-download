class CardDeckSolution:
    def __init__(self):
        self.suits = ['♠', '♣', '♥', '♦']
        self.values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']

    def __iter__(self):
        for suit in self.suits:
            for value in self.values:
                yield f"{value}{suit}"


# Test code
def test_card_deck():
    print("Testing CardDeck:")
    deck = CardDeckSolution()

    print("\nTest 1: First 5 cards")
    for card in list(deck)[:5]:
        print(card, end=' ')

    print("\n\nTest 2: Cards in first suit")
    for card in deck:
        if '♠' in card:
            print(card, end=' ')

    print("\n\nTest 3: Multiple iterations")
    deck2 = CardDeckSolution()
    print("Number of cards in deck:", len(list(deck2)))  # Should be 52
    print("Can iterate again:", len(list(deck2)))  # Should still be 52


if __name__ == "__main__":
    test_card_deck()