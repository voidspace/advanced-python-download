import time


class Timer:
    def __enter__(self):
        self.start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.end_time = time.time()
        execution_time = self.end_time - self.start_time
        print(f"Code executed in {execution_time:.3f} seconds")
        return False  # Don't suppress exceptions

if __name__ == '__main__':
    with Timer() as timer:
        # Some time-consuming operation
        for _ in range(1000000):
            _ = 2 ** 8
