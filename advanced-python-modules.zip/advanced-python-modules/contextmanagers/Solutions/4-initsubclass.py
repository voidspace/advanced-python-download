# Base class
class Animal:
    # Default that must be overridden
    __init__ = None

    # This method is automatically called when a subclass is defined
    def __init_subclass__(cls, **kwargs):
        # Ensure that the subclass defines the 'species' class variable
        if not hasattr(cls, 'species'):
            raise TypeError(f"Subclass '{cls.__name__}' must define a 'species' class attribute")

        # Ensure that the subclass has an '__init__' method
        if not callable(getattr(cls, '__init__', None)):
            raise NotImplementedError(f"Subclass '{cls.__name__}' must implement an '__init__' method")

        super().__init_subclass__(**kwargs)


# Valid subclass
class Dog(Animal):
    species = 'Dog'

    def __init__(self, name):
        self.name = name


# Invalid subclass (missing 'species')
try:
    class Cat(Animal):
        pass
except TypeError as e:
    print(f"Error successfully raised: {e}")
else:
    raise Exception("This should not be possible")


# Another valid subclass with its own behavior
class Bird(Animal):
    species = 'Bird'

    def __init__(self, name, wingspan):
        self.name = name
        self.wingspan = wingspan


# Create an instance of the valid subclasses
dog = Dog("Buddy")
print(f"{dog.name} is a {dog.species}.")

bird = Bird("Robin", 12)
print(f"{bird.name} is a {bird.species} with a wingspan of {bird.wingspan} cm.")

# (Optional) Invalid subclass (missing '__init__')
try:
    class Thing(Animal):
        species = 'thing'
except NotImplementedError as e:
    print(f"Error successfully raised: {e}")
else:
    raise Exception("This should not be possible")
