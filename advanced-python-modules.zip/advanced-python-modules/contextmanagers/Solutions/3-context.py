from contextlib import contextmanager
import time

@contextmanager
def Timer():
    start_time = time.time()
    try:
        yield
    finally:
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"Code executed in {execution_time:.3f} seconds")


if __name__ == '__main__':
    with Timer() as timer:
        # Some time-consuming operation
        for _ in range(1000000):
            _ = 2 ** 8


import os
from pathlib import Path


@contextmanager
def WorkingDirectory(path, silence_errors=False):
    target_path = Path(path)
    original_path = Path.cwd()
    try:
        os.chdir(target_path)
        yield
    except OSError:
        if not silence_errors:
            raise
    finally:
        os.chdir(original_path)


# Test 1: Basic usage
def test_basic_usage():
    original_dir = Path.cwd()
    with WorkingDirectory(".."):
        # Should be in parent directory
        print(f"Current directory: {Path.cwd()}")
    # Should be back in original directory
    assert original_dir == Path.cwd()
    print("Back in original directory")

# Test 2: silence_errors argument
def test_silence_errors():
    original_dir = Path.cwd()

    # This should not raise an exception
    with WorkingDirectory("..", silence_errors=True):
        open('non-existent-file')

    assert original_dir == Path.cwd()
    print("Back in original directory")

# Test 3: Error handling
def test_error_handling():
    original_dir = Path.cwd()
    try:
        with WorkingDirectory("nonexistent_directory"):
            print("This shouldn't print")
    except FileNotFoundError:
        print("Caught expected error for nonexistent directory")
    else:
        print('Expected exception was not raised!!!')
        raise Exception('problem')

    assert original_dir == Path.cwd()
    print("Still in original directory after error")


if __name__ == '__main__':
    test_basic_usage()
    test_silence_errors()
    test_error_handling()
