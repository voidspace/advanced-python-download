import os
from pathlib import Path

class WorkingDirectory:
    def __init__(self, path, silence_errors=False):
        self.target_path = Path(path)
        self.original_path = None
        self.silence_errors = silence_errors

    def __enter__(self):
        self.original_path = Path.cwd()
        os.chdir(self.target_path)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        os.chdir(self.original_path)
        if not self.silence_errors:
            return False  # Don't suppress exceptions

        # Return True for OSError exceptions
        return isinstance(exc_val, OSError)

# Test 1: Basic usage
def test_basic_usage():
    original_dir = Path.cwd()
    with WorkingDirectory(".."):
        # Should be in parent directory
        print(f"Current directory: {Path.cwd()}")
    # Should be back in original directory
    assert original_dir == Path.cwd()
    print("Back in original directory")

# Test 2: silence_errors argument
def test_silence_errors():
    original_dir = Path.cwd()

    # This should not raise an exception
    with WorkingDirectory("..", silence_errors=True):
        open('non-existent-file')

    assert original_dir == Path.cwd()
    print("Back in original directory")

# Test 3: Error handling
def test_error_handling():
    original_dir = Path.cwd()
    try:
        with WorkingDirectory("nonexistent_directory"):
            print("This shouldn't print")
    except FileNotFoundError:
        print("Caught expected error for nonexistent directory")
    else:
        print('Expected exception was not raised!!!')
        raise Exception('problem')

    assert original_dir == Path.cwd()
    print("Still in original directory after error")


if __name__ == '__main__':
    test_basic_usage()
    test_silence_errors()
    test_error_handling()
