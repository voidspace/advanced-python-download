class File:
    def __init__(self, filename, method='rt'):
        self.filename = filename
        self.method = method

    def __enter__(self):
        self.handle = open(self.filename, self.method)
        return self.handle

    def __exit__(self, typ, value, traceback):
        # Ignore these arguments for the moment
        self.handle.close()


with File('contextmanagers.pdf', 'wt') as handle:
    assert not handle.closed
    data = handle.read()

assert handle.closed